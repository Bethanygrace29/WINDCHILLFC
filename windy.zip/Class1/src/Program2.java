import
java.util.Scanner;//Scanner is in the java util package
public class Program2 {
	public static void
	{
Scanner input = new
//Prompt the user to enter the temperature
	Scanner(System.in);
System.out.println("What is the current temperature in Fahrenheit:");
double F = input.nextDouble();

//Compute Celsius
double Celsius = ((F - 32) * 5)/9
//Prompt user to enter windchill
System.out.println("What is the current wind speed in MPH:");
//compute temperature
	}
}